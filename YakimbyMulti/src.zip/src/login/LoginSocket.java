package login;

import estaticos.*;
import variables.Cuenta;
import variables.Servidor;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Maneja la conexión y autenticación de un cliente Dofus
 * 
 * Flujo de autenticación:
 * 1. CLIENTE: Envía versión del cliente
 * 2. CUENTA: Envía nombre de cuenta
 * 3. PASSWORD: Envía contraseña encriptada
 * 4. DEFAULT: Selección de servidor y otras operaciones
 */
public class LoginSocket implements Runnable {
    
    // Estados del flujo de autenticación
    private static final String ESTADO_CLIENTE = "CLIENTE";
    private static final String ESTADO_CUENTA = "CUENTA";
    private static final String ESTADO_PASSWORD = "PASSWORD";
    private static final String ESTADO_DEFAULT = "DEFAULT";
    
    private Socket socket;
    private BufferedInputStream in;
    private PrintWriter out;
    private String actualIP;
    private String codigoLlave;
    private String nombreCuenta;
    private String estadoActual;
    private Cuenta cuenta;
    private int intentos;
    private boolean corriendo;
    
    public LoginSocket(Socket socket) {
        try {
            this.socket = socket;
            this.actualIP = socket.getInetAddress().getHostAddress();
            this.in = new BufferedInputStream(socket.getInputStream());
            this.out = new PrintWriter(socket.getOutputStream());
            this.estadoActual = ESTADO_CLIENTE;
            this.intentos = 0;
            this.corriendo = true;
            
            LoginServer.addCliente(this);
            
            Thread thread = new Thread(this);
            thread.setDaemon(true);
            thread.start();
            
        } catch (IOException e) {
            MainMultiLogin.escribirLog("[LOGIN] Error al crear socket: " + e.getMessage());
            desconectar();
        }
    }
    
    @Override
    public void run() {
        try {
            // Enviar policy file y código llave
            GestorSalida.ENVIAR_POLICY_FILE(out);
            codigoLlave = GestorSalida.ENVIAR_HC_CODIGO_LLAVE(out);
            
            int c;
            int length = -1;
            int index = 0;
            byte[] bytes = new byte[1];
            
            while (corriendo && (c = in.read()) != -1) {
                if (length == -1) {
                    length = in.available();
                    bytes = new byte[length + 1];
                    index = 0;
                }
                
                bytes[index++] = (byte) c;
                
                if (bytes.length == index) {
                    String tempPacket = new String(bytes, StandardCharsets.UTF_8);
                    for (String packet : tempPacket.split("[\u0000\n\r]")) {
                        if (!packet.isEmpty()) {
                            if (MainMultiLogin.MOSTRAR_RECIBIDOS) {
                                System.out.println("[LOGIN] << " + packet);
                            }
                            procesarPacket(packet);
                        }
                    }
                    length = -1;
                }
            }
        } catch (Exception e) {
            if (corriendo && MainMultiLogin.MODO_DEBUG) {
                MainMultiLogin.escribirLog("[LOGIN] Error en conexión: " + e.getMessage());
            }
        } finally {
            limpiarCuenta();
            desconectar();
        }
    }
    
    /**
     * Procesa un packet recibido
     */
    private void procesarPacket(String packet) {
        try {
            switch (estadoActual) {
                case ESTADO_CLIENTE:
                    procesarCliente(packet);
                    break;
                case ESTADO_CUENTA:
                    procesarCuenta(packet);
                    break;
                case ESTADO_PASSWORD:
                    procesarPassword(packet);
                    break;
                case ESTADO_DEFAULT:
                    procesarDefault(packet);
                    break;
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[LOGIN] Error procesando packet: " + e.getMessage());
            GestorSalida.ENVIAR_AlEp_CUENTA_NO_VALIDA(out);
            desconectar();
        }
    }
    
    /**
     * Procesa packet en estado CLIENTE (verificación de versión)
     */
    private void procesarCliente(String packet) {
        // Policy file request de Flash
        if (packet.equalsIgnoreCase("<policy-file-request/>")) {
            return;
        }
        
        // Limpiar espacios y caracteres especiales del packet recibido
        String packetLimpio = packet.trim();
        // Eliminar caracteres de control (null bytes, etc.) y espacios al final
        packetLimpio = packetLimpio.replaceAll("[\\x00-\\x1F]", "").trim();
        
        // El cliente 1.43.7 envía la versión con formato: "1.43.7|es" (versión|idioma)
        // Extraer solo la parte de la versión (antes del |)
        String versionRecibida = packetLimpio;
        if (packetLimpio.contains("|")) {
            versionRecibida = packetLimpio.split("\\|")[0].trim();
            System.out.println("[MULTILOGIN-LOGIN] Packet contiene '|' - extrayendo versión: '" + versionRecibida + "'");
        }
        
        // Obtener versión esperada (ya está con trim en la carga de config)
        String versionEsperada = MainMultiLogin.VERSION_CLIENTE.trim();
        
        // Log para debug - ver qué envía el cliente
        System.out.println("[MULTILOGIN-LOGIN] ========== VERIFICACIÓN DE VERSIÓN ==========");
        System.out.println("[MULTILOGIN-LOGIN] Cliente envió: '" + packet + "' (longitud: " + packet.length() + ")");
        System.out.println("[MULTILOGIN-LOGIN] Packet limpiado: '" + packetLimpio + "'");
        System.out.println("[MULTILOGIN-LOGIN] Versión extraída: '" + versionRecibida + "'");
        System.out.println("[MULTILOGIN-LOGIN] Versión esperada: '" + versionEsperada + "'");
        
        // Verificar versión del cliente (aceptar "ANY" o comparar versiones limpias)
        boolean versionValida = false;
        // Verificar si es "ANY" (case-insensitive, sin espacios)
        String versionEsperadaLimpia = versionEsperada.trim();
        if (versionEsperadaLimpia.equalsIgnoreCase("ANY")) {
            versionValida = true;
            System.out.println("[MULTILOGIN-LOGIN] ✓ Modo ANY activado - aceptando cualquier versión");
            System.out.println("[MULTILOGIN-LOGIN] ✓ Cliente con versión: '" + versionRecibida + "'");
        } else {
            // Comparación exacta
            if (versionRecibida.equals(versionEsperada)) {
                versionValida = true;
                System.out.println("[MULTILOGIN-LOGIN] ✓ Versión coincide exactamente");
            } else {
                // Comparación ignorando mayúsculas/minúsculas
                if (versionRecibida.equalsIgnoreCase(versionEsperada)) {
                    versionValida = true;
                    System.out.println("[MULTILOGIN-LOGIN] ✓ Versión coincide (case-insensitive)");
                } else {
                    System.out.println("[MULTILOGIN-LOGIN] ✗ Versión NO coincide");
                    System.out.println("[MULTILOGIN-LOGIN]   Recibida: '" + versionRecibida + "'");
                    System.out.println("[MULTILOGIN-LOGIN]   Esperada: '" + versionEsperada + "'");
                    // Mostrar diferencias byte por byte para debug
                    System.out.println("[MULTILOGIN-LOGIN] Bytes recibidos:");
                    for (int i = 0; i < versionRecibida.length() && i < 20; i++) {
                        char c = versionRecibida.charAt(i);
                        System.out.print("  [" + i + "] '" + c + "' (ASCII: " + (int)c + ")");
                    }
                    System.out.println();
                    System.out.println("[MULTILOGIN-LOGIN] Bytes esperados:");
                    for (int i = 0; i < versionEsperada.length() && i < 20; i++) {
                        char c = versionEsperada.charAt(i);
                        System.out.print("  [" + i + "] '" + c + "' (ASCII: " + (int)c + ")");
                    }
                    System.out.println();
                }
            }
        }
        System.out.println("[MULTILOGIN-LOGIN] ==============================================");
        
        if (versionValida) {
            System.out.println("[MULTILOGIN-LOGIN] ✓ Versión aceptada, continuando con login...");
            estadoActual = ESTADO_CUENTA;
        } else {
            // Versión no válida
            System.out.println("[MULTILOGIN-LOGIN] >>> VERSION DESCONOCIDA - RECHAZANDO <<<");
            System.out.println("[MULTILOGIN-LOGIN] IP: " + actualIP);
            System.out.println("[MULTILOGIN-LOGIN] Packet original: '" + packet + "'");
            System.out.println("[MULTILOGIN-LOGIN] Packet limpiado: '" + versionRecibida + "'");
            System.out.println("[MULTILOGIN-LOGIN] Versión esperada: '" + versionEsperada + "'");
            System.out.println("[MULTILOGIN-LOGIN] Longitud packet: " + packet.length());
            System.out.println("[MULTILOGIN-LOGIN] Bytes del packet (primeros 30):");
            for (int i = 0; i < packet.length() && i < 30; i++) {
                char c = packet.charAt(i);
                System.out.print("[" + i + "]=" + (int)c + "('" + (c >= 32 && c < 127 ? c : '?') + "') ");
                if ((i + 1) % 5 == 0) System.out.println();
            }
            System.out.println();
            System.out.println("[MULTILOGIN-LOGIN] ========================================");
            GestorSalida.ENVIAR_AlEv_ERROR_VERSION(out);
            desconectar();
        }
    }
    
    /**
     * Procesa packet en estado CUENTA (recibe nombre de usuario)
     * El cliente 1.43.7 puede enviar "login\npassword" en un solo packet
     */
    private void procesarCuenta(String packet) {
        System.out.println("[MULTILOGIN-LOGIN] ========== PROCESANDO CUENTA ==========");
        System.out.println("[MULTILOGIN-LOGIN] Packet recibido: '" + packet + "' (longitud: " + packet.length() + ")");
        
        // El cliente 1.43.7 puede enviar "login\npassword" en un solo packet
        if (packet.contains("\n")) {
            System.out.println("[MULTILOGIN-LOGIN] Packet contiene '\\n' - formato cliente 1.43.7 detectado");
            String[] partes = packet.split("\n", 2);
            if (partes.length >= 1) {
                nombreCuenta = Encriptador.filtrar(partes[0]);
                System.out.println("[MULTILOGIN-LOGIN] Nombre de cuenta extraído: '" + nombreCuenta + "'");
                
                if (partes.length >= 2) {
                    // La contraseña viene en el mismo packet
                    System.out.println("[MULTILOGIN-LOGIN] Contraseña detectada en el mismo packet");
                    estadoActual = ESTADO_PASSWORD;
                    try {
                        procesarPassword(partes[1]);
                    } catch (Exception e) {
                        System.out.println("[MULTILOGIN-LOGIN] Error procesando contraseña: " + e.getMessage());
                        e.printStackTrace();
                    }
                    return;
                }
            }
        } else {
            // Formato tradicional: solo nombre de cuenta
            nombreCuenta = Encriptador.filtrar(packet);
            System.out.println("[MULTILOGIN-LOGIN] Nombre de cuenta: '" + nombreCuenta + "'");
        }
        
        estadoActual = ESTADO_PASSWORD;
        System.out.println("[MULTILOGIN-LOGIN] Estado cambiado a PASSWORD");
        System.out.println("[MULTILOGIN-LOGIN] ========================================");
    }
    
    /**
     * Procesa packet en estado PASSWORD (autenticación)
     * El cliente 1.43.7 puede enviar la contraseña en diferentes formatos:
     * - "#1..." (formato tradicional)
     * - "#2..." (formato MD5)
     * - Contraseña sin cifrar (dependiendo de la configuración)
     */
    private void procesarPassword(String packet) throws Exception {
        System.out.println("[MULTILOGIN-LOGIN] ========== PROCESANDO PASSWORD ==========");
        System.out.println("[MULTILOGIN-LOGIN] Packet recibido: '" + packet + "' (longitud: " + packet.length() + ")");
        System.out.println("[MULTILOGIN-LOGIN] Nombre de cuenta: '" + nombreCuenta + "'");
        
        // Verificar formato de contraseña
        // El cliente 1.43.7 puede enviar "#1...", "#2..." o sin prefijo
        boolean formatoValido = false;
        String metodoCifrado = "desconocido";
        
        if (packet.startsWith("#1")) {
            formatoValido = true;
            metodoCifrado = "#1 (tradicional)";
        } else if (packet.startsWith("#2")) {
            formatoValido = true;
            metodoCifrado = "#2 (MD5)";
        } else if (packet.length() > 0) {
            // Posiblemente sin prefijo (cliente 1.43.7 sin cifrado específico)
            formatoValido = true;
            metodoCifrado = "sin prefijo";
        }
        
        System.out.println("[MULTILOGIN-LOGIN] Método de cifrado detectado: " + metodoCifrado);
        
        if (!formatoValido || packet.length() < 1) {
            System.out.println("[MULTILOGIN-LOGIN] ✗ Formato de contraseña inválido");
            GestorSalida.enviar(out, "ATE");
            desconectar();
            return;
        }
        
        // Buscar cuenta
        System.out.println("[MULTILOGIN-LOGIN] Buscando cuenta: '" + nombreCuenta + "'");
        cuenta = Mundo.getCuentaPorNombre(nombreCuenta);
        if (cuenta == null) {
            System.out.println("[MULTILOGIN-LOGIN] Cuenta no encontrada en memoria, buscando en BD...");
            // Intentar cargar desde BD
            cuenta = GestorSQL.cargarCuentaPorNombre(nombreCuenta);
            if (cuenta != null) {
                System.out.println("[MULTILOGIN-LOGIN] ✓ Cuenta cargada desde BD");
                Mundo.addCuenta(cuenta);
            } else {
                System.out.println("[MULTILOGIN-LOGIN] ✗ Cuenta no encontrada en BD");
            }
        } else {
            System.out.println("[MULTILOGIN-LOGIN] ✓ Cuenta encontrada en memoria");
        }
        
        if (cuenta == null) {
            System.out.println("[MULTILOGIN-LOGIN] ✗ Cuenta no válida - enviando error");
            GestorSalida.ENVIAR_AlEp_CUENTA_NO_VALIDA(out);
            desconectar();
            return;
        }
        
        // Verificar contraseña
        System.out.println("[MULTILOGIN-LOGIN] Verificando contraseña...");
        System.out.println("[MULTILOGIN-LOGIN] Código llave: '" + codigoLlave + "'");
        
        String contrasenaBD = GestorSQL.getContrasenaCuenta(nombreCuenta);
        System.out.println("[MULTILOGIN-LOGIN] Contraseña en BD: '" + (contrasenaBD != null ? "***" : "null") + "'");
        
        boolean contrasenaValida = false;
        
        // Verificar según el formato recibido
        if (packet.startsWith("#2")) {
            // Formato MD5: "#2" + MD5(MD5(password) + codigoLlave)
            System.out.println("[MULTILOGIN-LOGIN] Verificando formato #2 (MD5)...");
            String hashRecibido = packet.substring(2); // Quitar "#2"
            
            // Calcular hash esperado: MD5(MD5(password) + codigoLlave)
            String hashPassword = Encriptador.md5(contrasenaBD);
            String hashEsperado = Encriptador.md5(hashPassword + codigoLlave);
            
            System.out.println("[MULTILOGIN-LOGIN] Hash recibido: '" + hashRecibido + "'");
            System.out.println("[MULTILOGIN-LOGIN] Hash esperado: '" + hashEsperado + "'");
            
            contrasenaValida = hashRecibido.equalsIgnoreCase(hashEsperado);
        } else if (packet.startsWith("#1")) {
            // Formato tradicional: "#1" + encriptación
            System.out.println("[MULTILOGIN-LOGIN] Verificando formato #1 (tradicional)...");
            
            // Intentar descifrar la contraseña recibida y comparar con la almacenada
            String contrasenaDescifrada = Encriptador.desencriptarContrasena(codigoLlave, packet);
            if (contrasenaDescifrada != null) {
                System.out.println("[MULTILOGIN-LOGIN] Contraseña descifrada: '" + contrasenaDescifrada + "'");
                System.out.println("[MULTILOGIN-LOGIN] Contraseña en BD: '" + contrasenaBD + "'");
                contrasenaValida = contrasenaDescifrada.equals(contrasenaBD);
                if (contrasenaValida) {
                    System.out.println("[MULTILOGIN-LOGIN] ✓ Contraseña válida (descifrado)");
                } else {
                    System.out.println("[MULTILOGIN-LOGIN] ✗ Contraseña no coincide después de descifrar");
                }
            } else {
                // Si el descifrado falla, intentar método tradicional (comparar hash con hash)
                System.out.println("[MULTILOGIN-LOGIN] Descifrado falló, intentando método tradicional...");
                String contrasenaEncriptada = Encriptador.encriptarContrasena(codigoLlave, contrasenaBD);
                System.out.println("[MULTILOGIN-LOGIN] Contraseña encriptada esperada: '" + contrasenaEncriptada + "'");
                System.out.println("[MULTILOGIN-LOGIN] Contraseña recibida: '" + packet + "'");
                contrasenaValida = packet.equals(contrasenaEncriptada);
            }
        } else {
            // Formato sin prefijo - intentar ambos métodos
            System.out.println("[MULTILOGIN-LOGIN] Verificando formato sin prefijo...");
            String contrasenaEncriptada = Encriptador.encriptarContrasena(codigoLlave, contrasenaBD);
            contrasenaValida = packet.equals(contrasenaEncriptada);
            
            // Si no coincide con formato tradicional, intentar MD5
            if (!contrasenaValida) {
                String hashPassword = Encriptador.md5(contrasenaBD);
                String hashEsperado = Encriptador.md5(hashPassword + codigoLlave);
                contrasenaValida = packet.equalsIgnoreCase(hashEsperado);
                if (contrasenaValida) {
                    System.out.println("[MULTILOGIN-LOGIN] ✓ Contraseña válida (formato MD5 sin prefijo)");
                }
            }
        }
        
        if (!contrasenaValida) {
            intentos++;
            System.out.println("[MULTILOGIN-LOGIN] ✗ Contraseña incorrecta (intento " + intentos + "/3)");
            if (intentos >= 3) {
                System.out.println("[MULTILOGIN-LOGIN] ✗ Máximo de intentos alcanzado");
                GestorSalida.ENVIAR_AlEx_PASS_INCORRECTA(out);
                desconectar();
            } else {
                GestorSalida.ENVIAR_AlEx_PASS_INCORRECTA(out);
            }
            return;
        }
        
        System.out.println("[MULTILOGIN-LOGIN] ✓ Contraseña válida");
        
        // Verificar IP baneada
        if (GestorSQL.esIPBaneada(actualIP)) {
            GestorSalida.ENVIAR_AlEb_CUENTA_BANEADA(out);
            desconectar();
            return;
        }
        
        // Verificar ban de cuenta
        long tiempoBan = cuenta.getBaneado();
        if (tiempoBan != 0) {
            if (tiempoBan == -1) {
                // Ban permanente
                GestorSalida.ENVIAR_AlEb_CUENTA_BANEADA(out);
                desconectar();
                return;
            } else if (tiempoBan > System.currentTimeMillis()) {
                // Ban temporal
                GestorSalida.ENVIAR_AlEk_CUENTA_BANEADA_TIEMPO(out, tiempoBan);
                desconectar();
                return;
            } else {
                // Ban expirado, limpiar
                GestorSQL.setBaneado(nombreCuenta, 0);
            }
        }
        
        // Verificar multicuenta
        Mundo.solicitarCantidadIPs(actualIP);
        Thread.sleep(100);
        
        int cuentasPorIP = LoginServer.getCantidadConexionesIP(actualIP);
        if (!MainMultiLogin.PERMITIR_MULTICUENTA && cuentasPorIP > 1) {
            GestorSalida.ENVIAR_M0_MENSAJE(out, "34", "Solo se permite 1 cuenta por IP");
            desconectar();
            return;
        }
        if (cuentasPorIP >= MainMultiLogin.MAX_CUENTAS_POR_IP) {
            GestorSalida.ENVIAR_M0_MENSAJE(out, "34", "Máximo " + MainMultiLogin.MAX_CUENTAS_POR_IP + " cuentas por IP");
            desconectar();
            return;
        }
        
        // Desconectar cuenta si ya está conectada
        if (cuenta.getSocket() != null && cuenta.getSocket() != this) {
            GestorSalida.ENVIAR_AlEd_YA_CONECTADO(cuenta.getSocket().getOut());
            cuenta.getSocket().desconectar();
        }
        
        // Login exitoso
        cuenta.setSocket(this);
        estadoActual = ESTADO_DEFAULT;
        
        // Actualizar última IP
        GestorSQL.actualizarUltimaIP(actualIP, cuenta.getId());
        
        // Enviar confirmación de login exitoso (Al) - CRÍTICO para que el cliente continúe
        // Este packet activa onLogin(true) en el cliente y permite que solicite la lista de personajes
        System.out.println("[MULTILOGIN-LOGIN] Enviando confirmación de login exitoso (Al)");
        GestorSalida.ENVIAR_Al_LOGIN_EXITOSO(out);
        
        // Enviar apodo y comunidad
        String apodo = GestorSQL.getApodo(nombreCuenta);
        if (apodo.isEmpty()) {
            apodo = nombreCuenta;
        }
        GestorSalida.ENVIAR_Ad_APODO(out, apodo);
        GestorSalida.ENVIAR_Ac_COMUNIDAD(out, 0); // Comunidad 0 = ES
        
        // Enviar lista de servidores (AH) - necesario antes de que el cliente solicite con Ax
        // El cliente 1.43.7 espera recibir AH con la información del servidor host
        GestorSalida.ENVIAR_AH_LISTA_SERVIDORES(out);
        
        // Enviar a todos los servidores la conexión de esta cuenta
        for (Servidor servidor : Mundo.getServidores().values()) {
            if (servidor.getConector() != null && !servidor.getConector().estaCerrado()) {
                servidor.getConector().enviarPacket("A" + cuenta.getId() + ";" + actualIP);
            }
        }
    }
    
    /**
     * Procesa packet en estado DEFAULT (operaciones post-login)
     */
    private void procesarDefault(String packet) {
        if (cuenta == null) {
            GestorSalida.ENVIAR_AlEp_CUENTA_NO_VALIDA(out);
            desconectar();
            return;
        }
        
        String comando = packet.length() >= 2 ? packet.substring(0, 2) : packet;
        
        switch (comando) {
            case "Af": // Solicitud de fila de espera / estado
                if (MainMultiLogin.ACTIVAR_FILA_ESPERA) {
                    GestorSalida.ENVIAR_Af_SU_TURNO(out);
                } else {
                    GestorSalida.ENVIAR_Af_SU_TURNO(out);
                }
                break;
                
            case "AL": // Solicitud de lista de personajes (AL o ALf)
                if (packet.length() > 2 && packet.charAt(2) == 'f') {
                    System.out.println("[MULTILOGIN-LOGIN] Cliente fuerza lista de personajes (ALf)");
                } else {
                    System.out.println("[MULTILOGIN-LOGIN] Cliente solicita lista de personajes (AL)");
                }
                procesarListaPersonajes();
                break;
                
            case "Ax": // Solicitud de lista de servidores
                System.out.println("[MULTILOGIN-LOGIN] Cliente solicita lista de servidores (Ax)");
                LoginServer.addEscogiendoServidor(this);
                // El cliente 1.43.7 espera AxK con formato: [subscription]|[id,count;id2,count2;...]
                GestorSalida.ENVIAR_AxK_LISTA_SERVIDORES(out, cuenta);
                break;
                
            case "AX": // Selección de servidor
                seleccionarServidor(packet.substring(2));
                break;
                
            case "AQ": // Pregunta secreta
                GestorSalida.ENVIAR_AQ_PREGUNTA_SECRETA(out, 
                    GestorSQL.getPreguntaSecreta(nombreCuenta));
                break;
                
            case "Ap": // Puerto de conexión configurado (cliente informa, no requiere respuesta)
                if (packet.length() > 2) {
                    String puerto = packet.substring(2);
                    System.out.println("[MULTILOGIN-LOGIN] Cliente informa puerto: " + puerto);
                }
                break;
                
            case "Ai": // Identidad del cliente (cliente informa, no requiere respuesta)
                if (packet.length() > 2) {
                    String identidad = packet.substring(2);
                    System.out.println("[MULTILOGIN-LOGIN] Cliente envía identidad: " + identidad);
                }
                break;
                
            case "AA": // Crear personaje: AA[name]|class|sex|color1|color2|color3
                procesarCrearPersonaje(packet.substring(2));
                break;
                
            case "AS": // Seleccionar personaje: AS[char_id]
                procesarSeleccionarPersonaje(packet.substring(2));
                break;
                
            case "AD": // Eliminar personaje: AD[char_id]|answer
                procesarEliminarPersonaje(packet.substring(2));
                break;
                
            case "AP": // Generar nombre aleatorio
                procesarGenerarNombreAleatorio();
                break;
                
            default:
                // Packet desconocido - posiblemente del cliente 1.43.7
                System.out.println("[MULTILOGIN-LOGIN] >>> PACKET DESCONOCIDO <<<");
                System.out.println("[MULTILOGIN-LOGIN] IP: " + actualIP + " | Usuario: " + (nombreCuenta != null ? nombreCuenta : "sin_cuenta"));
                System.out.println("[MULTILOGIN-LOGIN] Estado: " + estadoActual);
                System.out.println("[MULTILOGIN-LOGIN] Packet: " + packet);
                System.out.println("[MULTILOGIN-LOGIN] Comando (2 chars): " + comando);
                System.out.println("[MULTILOGIN-LOGIN] Longitud: " + packet.length());
                System.out.println("[MULTILOGIN-LOGIN] ========================================");
        }
    }
    
    /**
     * Procesa la solicitud de lista de personajes
     * Envía ALK con la lista de personajes (o lista vacía si no hay)
     */
    private void procesarListaPersonajes() {
        // Por ahora, el MultiLogin no maneja personajes directamente
        // Los personajes se gestionan en el servidor Mundo
        // Enviar lista vacía para que el cliente pueda crear un personaje o seleccionar servidor
        long subscription = System.currentTimeMillis() + (365L * 24 * 60 * 60 * 1000); // 1 año
        int count = 0; // Sin personajes por ahora
        String personajesData = ""; // Lista vacía
        
        System.out.println("[MULTILOGIN-LOGIN] Enviando lista de personajes (ALK) - " + count + " personajes");
        GestorSalida.ENVIAR_ALK_LISTA_PERSONAJES(out, subscription, count, personajesData);
    }
    
    /**
     * Procesa la creación de un personaje
     * Formato: AA[name]|class|sex|color1|color2|color3
     */
    private void procesarCrearPersonaje(String datos) {
        System.out.println("[MULTILOGIN-LOGIN] Cliente solicita crear personaje: " + datos);
        // Por ahora, el MultiLogin no maneja creación de personajes
        // Esto debería delegarse al servidor Mundo
        // Responder con error por ahora
        GestorSalida.ENVIAR_AAK_PERSONAJE_CREADO(out, null);
    }
    
    /**
     * Procesa la selección de un personaje
     * Formato: AS[char_id]
     */
    private void procesarSeleccionarPersonaje(String charIdStr) {
        System.out.println("[MULTILOGIN-LOGIN] Cliente selecciona personaje: " + charIdStr);
        try {
            int charId = Integer.parseInt(charIdStr);
            // Por ahora, el MultiLogin no maneja personajes
            // Esto debería delegarse al servidor Mundo
            // Responder con error por ahora
            GestorSalida.ENVIAR_ASK_PERSONAJE_SELECCIONADO(out, "");
        } catch (NumberFormatException e) {
            GestorSalida.ENVIAR_ASK_PERSONAJE_SELECCIONADO(out, "");
        }
    }
    
    /**
     * Procesa la eliminación de un personaje
     * Formato: AD[char_id]|answer
     */
    private void procesarEliminarPersonaje(String datos) {
        System.out.println("[MULTILOGIN-LOGIN] Cliente solicita eliminar personaje: " + datos);
        // Por ahora, el MultiLogin no maneja eliminación de personajes
        // Esto debería delegarse al servidor Mundo
        GestorSalida.ENVIAR_ADK_PERSONAJE_ELIMINADO(out, false);
    }
    
    /**
     * Procesa la solicitud de nombre aleatorio
     */
    private void procesarGenerarNombreAleatorio() {
        System.out.println("[MULTILOGIN-LOGIN] Cliente solicita nombre aleatorio");
        // Generar un nombre aleatorio simple
        String[] nombres = {"Aragorn", "Legolas", "Gimli", "Frodo", "Sam", "Merry", "Pippin", "Gandalf"};
        String nombre = nombres[(int)(Math.random() * nombres.length)] + (int)(Math.random() * 1000);
        GestorSalida.ENVIAR_APK_NOMBRE_ALEATORIO(out, nombre);
    }
    
    /**
     * Procesa la selección de un servidor
     */
    private void seleccionarServidor(String idStr) {
        try {
            int servidorId = Integer.parseInt(idStr);
            Servidor servidor = Mundo.getServidor(servidorId);
            
            if (servidor == null || servidor.getEstado() == Servidor.SERVIDOR_OFFLINE) {
                GestorSalida.ENVIAR_AlEn_SERVIDOR_NO_DISPONIBLE(out);
                return;
            }
            
            if (servidor.getConector() == null || servidor.getConector().estaCerrado()) {
                GestorSalida.ENVIAR_AlEn_SERVIDOR_NO_DISPONIBLE(out);
                return;
            }
            
            // Enviar IP y puerto del servidor al cliente
            LoginServer.removeEscogiendoServidor(this);
            GestorSalida.ENVIAR_AXK_CONECTAR_SERVIDOR(out, cuenta.getId(), servidor.getIp(), servidor.getPuerto());
            
        } catch (NumberFormatException e) {
            GestorSalida.ENVIAR_AlEn_SERVIDOR_NO_DISPONIBLE(out);
        }
    }
    
    /**
     * Limpia la referencia a la cuenta
     */
    private void limpiarCuenta() {
        if (cuenta != null) {
            if (cuenta.getSocket() == this) {
                cuenta.setSocket(null);
            }
        }
    }
    
    /**
     * Desconecta el socket
     */
    public void desconectar() {
        corriendo = false;
        LoginServer.removeCliente(this);
        
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            // Ignorar
        }
    }
    
    // Getters
    public PrintWriter getOut() { return out; }
    public String getActualIP() { return actualIP; }
    public Cuenta getCuenta() { return cuenta; }
    
    /**
     * Genera el packet para notificar la conexión al servidor de juego
     */
    public String getPacketConexion() {
        if (cuenta == null) return "";
        return "A" + cuenta.getId() + ";" + actualIP;
    }
}

