package variables;

import sincronizador.SincronizadorSocket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Representa un servidor de juego conectado al Multi-Login
 */
public class Servidor {
    
    public static final int SERVIDOR_OFFLINE = 0;
    public static final int SERVIDOR_ONLINE = 1;
    public static final int SERVIDOR_SAVING = 2;
    
    private final int id;
    private int puerto;
    private int estado;
    private int prioridad;
    private int conectados;
    private String ip;
    private SincronizadorSocket conector;
    private final Map<String, Integer> ipsCantidad;
    
    public Servidor(int id, int puerto, int estado) {
        this.id = id;
        this.puerto = puerto;
        this.estado = estado;
        this.prioridad = 0;
        this.conectados = 0;
        this.ip = "127.0.0.1";
        this.conector = null;
        this.ipsCantidad = new ConcurrentHashMap<>();
    }
    
    // Getters
    public int getId() { return id; }
    public int getPuerto() { return puerto; }
    public int getEstado() { return estado; }
    public int getPrioridad() { return prioridad; }
    public int getConectados() { return conectados; }
    public String getIp() { return ip; }
    public SincronizadorSocket getConector() { return conector; }
    
    // Setters
    public void setPuerto(int puerto) { this.puerto = puerto; }
    public void setEstado(int estado) { this.estado = estado; }
    public void setPrioridad(int prioridad) { this.prioridad = prioridad; }
    public void setConectados(int conectados) { this.conectados = conectados; }
    public void setIp(String ip) { this.ip = ip; }
    public void setConector(SincronizadorSocket conector) { this.conector = conector; }
    
    /**
     * Establece la cantidad de conexiones desde una IP específica
     */
    public void setCantidadIp(String ip, int cantidad) {
        ipsCantidad.put(ip, cantidad);
    }
    
    /**
     * Obtiene la cantidad de conexiones desde una IP específica
     */
    public int getCantidadPorIP(String ip) {
        return ipsCantidad.getOrDefault(ip, 0);
    }
    
    /**
     * Genera el string para el packet AH (lista de servidores)
     * Formato esperado por cliente 1.43.7: ID;Estado;Población;Comunidad
     * Estado: 0=offline, 1=online, 2=starting
     * Población: 0=baja, 1=media, 2=alta (NO el número de jugadores)
     * Comunidad: tipo de comunidad (0=ES, 1=FR, etc.)
     */
    public String getStringParaAH() {
        // Asegurar que los valores sean numéricos válidos
        int estadoNum = (estado == SERVIDOR_ONLINE ? 1 : (estado == SERVIDOR_SAVING ? 2 : 0));
        
        // Convertir número de jugadores a nivel de población (0-2)
        // 0=baja, 1=media, 2=alta
        int poblacion;
        if (conectados == 0) {
            poblacion = 0; // Baja
        } else if (conectados < 50) {
            poblacion = 1; // Media
        } else {
            poblacion = 2; // Alta
        }
        
        int comunidad = 0; // 0 = ES por defecto
        
        return id + ";" + estadoNum + ";" + poblacion + ";" + comunidad;
    }
    
    /**
     * Verifica si el servidor está online y accesible
     */
    public boolean estaDisponible() {
        return estado == SERVIDOR_ONLINE && conector != null && !conector.estaCerrado();
    }
    
    @Override
    public String toString() {
        return "Servidor[id=" + id + ", puerto=" + puerto + ", estado=" + estado + ", conectados=" + conectados + "]";
    }
}

