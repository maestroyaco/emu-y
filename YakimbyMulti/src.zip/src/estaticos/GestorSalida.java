package estaticos;

import variables.Cuenta;
import variables.Servidor;
import java.io.PrintWriter;

/**
 * Gestor de packets de salida para el Multi-Login
 * Envía respuestas al cliente Dofus
 */
public class GestorSalida {
    
    /**
     * Envía un packet al cliente
     */
    public static void enviar(PrintWriter out, String packet) {
        if (out == null || packet == null || packet.isEmpty()) return;
        
        if (MainMultiLogin.MOSTRAR_ENVIADOS) {
            System.out.println(">> ENVIAR: " + packet);
        }
        
        out.print(packet + (char) 0x00);
        out.flush();
    }
    
    // ==================== PACKETS DE CONEXIÓN ====================
    
    /**
     * Envía el archivo de política XML (Flash)
     */
    public static void ENVIAR_POLICY_FILE(PrintWriter out) {
        String policy = "<?xml version=\"1.0\"?>" +
            "<!DOCTYPE cross-domain-policy SYSTEM \"http://www.macromedia.com/xml/dtds/cross-domain-policy.dtd\">" +
            "<cross-domain-policy>" +
            "<allow-access-from domain=\"*\" to-ports=\"*\" />" +
            "</cross-domain-policy>";
        enviar(out, policy);
    }
    
    /**
     * Envía el código llave para encriptar la contraseña
     * Packet: HC + codigoLlave
     */
    public static String ENVIAR_HC_CODIGO_LLAVE(PrintWriter out) {
        String codigoLlave = Encriptador.generarCodigoLlave();
        enviar(out, "HC" + codigoLlave);
        return codigoLlave;
    }
    
    // ==================== PACKETS DE ERRORES ====================
    
    /**
     * Error: Versión del cliente incorrecta
     * Packet: AlEv + versión (sin espacios)
     */
    public static void ENVIAR_AlEv_ERROR_VERSION(PrintWriter out) {
        // Asegurar que no haya espacios en la versión
        String version = MainMultiLogin.VERSION_CLIENTE.trim();
        String packet = "AlEv" + version;
        System.out.println("[MULTILOGIN] Enviando error de versión: '" + packet + "' (versión: '" + version + "')");
        enviar(out, packet);
    }
    
    /**
     * Error: Cuenta no válida o no existe
     */
    public static void ENVIAR_AlEp_CUENTA_NO_VALIDA(PrintWriter out) {
        enviar(out, "AlEp");
    }
    
    /**
     * Error: Nombre o contraseña incorrecta
     */
    public static void ENVIAR_AlEx_PASS_INCORRECTA(PrintWriter out) {
        enviar(out, "AlEx");
    }
    
    /**
     * Error: Cuenta baneada permanentemente
     */
    public static void ENVIAR_AlEb_CUENTA_BANEADA(PrintWriter out) {
        enviar(out, "AlEb");
    }
    
    /**
     * Error: Cuenta baneada temporalmente
     * Packet: AlEk + tiempoRestante
     */
    public static void ENVIAR_AlEk_CUENTA_BANEADA_TIEMPO(PrintWriter out, long tiempoFin) {
        enviar(out, "AlEk" + tiempoFin);
    }
    
    /**
     * Error: Ya conectado en otro lugar
     */
    public static void ENVIAR_AlEd_YA_CONECTADO(PrintWriter out) {
        enviar(out, "AlEd");
    }
    
    /**
     * Error: Conexión no terminada (servidor no disponible)
     */
    public static void ENVIAR_AlEn_SERVIDOR_NO_DISPONIBLE(PrintWriter out) {
        enviar(out, "AlEn");
    }
    
    /**
     * Error: Servidor lleno
     */
    public static void ENVIAR_AlEw_SERVIDOR_LLENO(PrintWriter out) {
        enviar(out, "AlEw");
    }
    
    // ==================== PACKETS DE ÉXITO ====================
    
    /**
     * Confirmación de login exitoso
     * Packet: Al
     * Este packet activa onLogin(true) en el cliente y permite que continúe
     */
    public static void ENVIAR_Al_LOGIN_EXITOSO(PrintWriter out) {
        enviar(out, "Al");
    }
    
    /**
     * Login exitoso - Envía apodo de la cuenta
     * Packet: Ad + apodo
     */
    public static void ENVIAR_Ad_APODO(PrintWriter out, String apodo) {
        enviar(out, "Ad" + apodo);
    }
    
    /**
     * Envía comunidad/idioma
     * Packet: Ac + idComunidad
     */
    public static void ENVIAR_Ac_COMUNIDAD(PrintWriter out, int comunidad) {
        enviar(out, "Ac" + comunidad);
    }
    
    /**
     * Envía lista de servidores disponibles
     * Packet: AH + servidor1|servidor2|...
     * Formato servidor: ID;Estado;Completitud;PuedeSeleccionar
     */
    public static void ENVIAR_AH_LISTA_SERVIDORES(PrintWriter out) {
        StringBuilder sb = new StringBuilder("AH");
        boolean primero = true;
        
        for (Servidor servidor : Mundo.getServidores().values()) {
            if (!primero) sb.append("|");
            sb.append(servidor.getStringParaAH());
            primero = false;
        }
        
        enviar(out, sb.toString());
    }
    
    /**
     * Envía lista de servidores disponibles con información de personajes
     * Packet: AxK + [subscription]|[id,count;id2,count2;...]
     * Formato esperado por cliente 1.43.7: AxK[subscription]|[id,count;id2,count2;...]
     * - subscription: tiempo de suscripción restante en milisegundos (0 si no es suscriptor)
     * - id,count: ID del servidor y número de personajes del usuario en ese servidor
     */
    public static void ENVIAR_AxK_LISTA_SERVIDORES(PrintWriter out, Cuenta cuenta) {
        // Obtener tiempo de suscripción (0 si no es suscriptor)
        // getTiempoAbono() retorna int, pero el cliente espera long (milisegundos)
        long subscription = cuenta != null ? (long) cuenta.getTiempoAbono() : 0;
        if (subscription < 0) subscription = 0;
        
        StringBuilder sb = new StringBuilder("AxK");
        sb.append(subscription);
        sb.append("|");
        
        // Agregar servidores con formato: id,count
        boolean primero = true;
        for (Servidor servidor : Mundo.getServidores().values()) {
            if (!primero) sb.append(";");
            int personajesCount = cuenta != null ? cuenta.getPersonajes(servidor.getId()) : 0;
            sb.append(servidor.getId()).append(",").append(personajesCount);
            primero = false;
        }
        
        System.out.println("[MULTILOGIN] Enviando AxK lista servidores: " + sb.toString());
        enviar(out, sb.toString());
    }
    
    /**
     * Envía información de suscripción y personajes
     * Packet: AxK + tiempoAbono|servidorID,nroPersonajes;...
     * NOTA: Este método NO debe usarse como respuesta a "Ax" del cliente
     * El cliente 1.43.7 espera ENVIAR_AxK_LISTA_SERVIDORES() cuando envía "Ax"
     */
    public static void ENVIAR_AxK_INFO_CUENTA(PrintWriter out, Cuenta cuenta) {
        // tiempoAbono (365 días = suscripción activa, 0 = sin suscripción)
        long tiempoAbono = 365 * 24 * 60 * 60 * 1000L; // 1 año en milisegundos
        
        StringBuilder sb = new StringBuilder("AxK");
        sb.append(System.currentTimeMillis() + tiempoAbono);
        sb.append("|");
        sb.append(cuenta.getStringPersonajesServidores());
        
        enviar(out, sb.toString());
    }
    
    /**
     * Fila de espera
     * Packet: Af + posición|totalEnCola|esAbonado|tiempoEstimado
     */
    public static void ENVIAR_Af_FILA_ESPERA(PrintWriter out, int posicion) {
        enviar(out, "Af" + posicion + "|" + posicion + "|0|0");
    }
    
    /**
     * Es su turno - puede continuar
     */
    public static void ENVIAR_Af_SU_TURNO(PrintWriter out) {
        enviar(out, "Af");
    }
    
    /**
     * Envía IP y puerto del servidor de juego para conectarse
     * Packet: AXK + ip|port|ticket
     * Formato esperado por cliente 1.43.7: AXK[ip]|[port]|[ticket]
     * El ticket es un identificador único para la conexión
     */
    public static void ENVIAR_AXK_CONECTAR_SERVIDOR(PrintWriter out, int cuentaId, String ip, int puerto) {
        // Generar ticket único para esta conexión
        // El ticket puede ser el ID de cuenta + timestamp + hash simple
        String ticket = generarTicket(cuentaId);
        
        // Formato AXK: ip|port|ticket (usando | como separador)
        String packet = "AXK" + ip + "|" + puerto + "|" + ticket;
        System.out.println("[MULTILOGIN] Enviando AXK: " + packet);
        enviar(out, packet);
    }
    
    /**
     * Genera un ticket único para la conexión al servidor de juego
     * El ticket se usa para autenticar la conexión en el servidor Mundo
     */
    private static String generarTicket(int cuentaId) {
        // Generar ticket simple: cuentaId + timestamp + hash
        long timestamp = System.currentTimeMillis();
        String ticket = cuentaId + "_" + timestamp + "_" + (int)(Math.random() * 10000);
        return ticket;
    }
    
    /**
     * Mensaje del servidor (popup)
     * Packet: M0 + tipo|mensaje
     */
    public static void ENVIAR_M0_MENSAJE(PrintWriter out, String tipo, String mensaje) {
        enviar(out, "M0" + tipo + "|" + mensaje);
    }
    
    /**
     * Envía pregunta secreta para recuperar contraseña
     */
    public static void ENVIAR_AQ_PREGUNTA_SECRETA(PrintWriter out, String pregunta) {
        enviar(out, "AQ" + pregunta);
    }
    
    // ==================== PACKETS DE PERSONAJES ====================
    
    /**
     * Envía lista de personajes
     * Packet: ALK + [subscription] + [count] + [character_data]
     * Formato: ALK[subscription][count][char1_data][char2_data]...
     * Formato personaje: [id]~[name]~[level]~[color1]~[color2]~[color3]~[skin]~[size]~[sex]~[gfxID]~[serverID]~[dead]~[deathCount]~[levelMax]
     */
    public static void ENVIAR_ALK_LISTA_PERSONAJES(PrintWriter out, long subscription, int count, String personajesData) {
        StringBuilder sb = new StringBuilder("ALK");
        sb.append(subscription);
        sb.append(count);
        if (personajesData != null && !personajesData.isEmpty()) {
            sb.append(personajesData);
        }
        enviar(out, sb.toString());
    }
    
    /**
     * Envía confirmación de selección de personaje
     * Packet: ASK + [character_data]
     * Formato: ASK[char_data] o ASK[ip];[port];[ticket]
     */
    public static void ENVIAR_ASK_PERSONAJE_SELECCIONADO(PrintWriter out, String datosPersonaje) {
        enviar(out, "ASK" + datosPersonaje);
    }
    
    /**
     * Envía confirmación de creación de personaje
     * Packet: AAK + [character_data] o AAK (error)
     */
    public static void ENVIAR_AAK_PERSONAJE_CREADO(PrintWriter out, String datosPersonaje) {
        if (datosPersonaje != null && !datosPersonaje.isEmpty()) {
            enviar(out, "AAK" + datosPersonaje);
        } else {
            enviar(out, "AAK"); // Error
        }
    }
    
    /**
     * Envía confirmación de eliminación de personaje
     * Packet: ADK (éxito) o ADK (error)
     */
    public static void ENVIAR_ADK_PERSONAJE_ELIMINADO(PrintWriter out, boolean exito) {
        enviar(out, "ADK" + (exito ? "" : ""));
    }
    
    /**
     * Envía nombre aleatorio generado
     * Packet: APK + [name]
     */
    public static void ENVIAR_APK_NOMBRE_ALEATORIO(PrintWriter out, String nombre) {
        if (nombre != null && !nombre.isEmpty()) {
            enviar(out, "APK" + nombre);
        } else {
            enviar(out, "APK"); // Error
        }
    }
}

