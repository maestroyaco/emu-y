package estaticos;

import variables.Cuenta;
import variables.Servidor;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Contenedor global de datos del Multi-Login
 * Almacena servidores y cuentas en memoria
 */
public class Mundo {
    
    // Mapa de servidores: ID -> Servidor
    private static final Map<Integer, Servidor> servidores = new ConcurrentHashMap<>();
    
    // Mapa de cuentas en memoria: ID -> Cuenta
    private static final Map<Integer, Cuenta> cuentas = new ConcurrentHashMap<>();
    
    // ==================== SERVIDORES ====================
    
    /**
     * Obtiene el mapa de servidores
     */
    public static Map<Integer, Servidor> getServidores() {
        return servidores;
    }
    
    /**
     * Obtiene un servidor por ID
     */
    public static Servidor getServidor(int id) {
        return servidores.get(id);
    }
    
    /**
     * Agrega o actualiza un servidor
     */
    public static void addServidor(Servidor servidor) {
        servidores.put(servidor.getId(), servidor);
    }
    
    /**
     * Elimina un servidor
     */
    public static void removeServidor(int id) {
        servidores.remove(id);
    }
    
    /**
     * Cuenta el total de jugadores conectados en todos los servidores
     */
    public static int getTotalConectados() {
        int total = 0;
        for (Servidor s : servidores.values()) {
            total += s.getConectados();
        }
        return total;
    }
    
    /**
     * Genera el string de estado para el archivo info_status.php
     */
    public static String getInfoStatus() {
        StringBuilder sb = new StringBuilder();
        for (Servidor s : servidores.values()) {
            sb.append("$server_").append(s.getId()).append("_status = ").append(s.getEstado()).append("; ");
            sb.append("$server_").append(s.getId()).append("_onlines = ").append(s.getConectados()).append("; ");
        }
        return sb.toString();
    }
    
    // ==================== CUENTAS ====================
    
    /**
     * Obtiene una cuenta por ID
     */
    public static Cuenta getCuenta(int id) {
        if (id <= 0) return null;
        
        // Buscar en memoria
        Cuenta cuenta = cuentas.get(id);
        if (cuenta != null) {
            return cuenta;
        }
        
        // Cargar desde BD
        cuenta = GestorSQL.cargarCuenta(id);
        if (cuenta != null) {
            cuentas.put(id, cuenta);
        }
        return cuenta;
    }
    
    /**
     * Obtiene una cuenta por nombre
     */
    public static Cuenta getCuentaPorNombre(String nombre) {
        int id = GestorSQL.getIdCuentaPorNombre(nombre);
        if (id > 0) {
            return getCuenta(id);
        }
        return null;
    }
    
    /**
     * Agrega una cuenta a la memoria
     */
    public static void addCuenta(Cuenta cuenta) {
        if (cuenta != null) {
            cuentas.put(cuenta.getId(), cuenta);
        }
    }
    
    /**
     * Elimina una cuenta de la memoria
     */
    public static void removeCuenta(int id) {
        cuentas.remove(id);
    }
    
    /**
     * Obtiene la cantidad de conexiones desde una IP en todos los servidores
     */
    public static int getCantidadConexionesIP(String ip) {
        int total = 0;
        for (Servidor s : servidores.values()) {
            total += s.getCantidadPorIP(ip);
        }
        return total;
    }
    
    /**
     * Envía solicitud de cantidad de IPs a todos los servidores
     */
    public static void solicitarCantidadIPs(String ip) {
        for (Servidor s : servidores.values()) {
            if (s.getConector() != null && !s.getConector().estaCerrado()) {
                s.getConector().enviarPacket("I" + ip);
            }
        }
    }
    
    /**
     * Inicializa el Multi-Login
     */
    public static void inicializar() {
        System.out.println("[MUNDO] Inicializando Multi-Login...");
        System.out.println("[MUNDO] " + servidores.size() + " servidores configurados");
    }
}

