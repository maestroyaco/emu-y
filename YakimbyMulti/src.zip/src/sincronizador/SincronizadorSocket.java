package sincronizador;

import estaticos.Encriptador;
import estaticos.MainMultiLogin;
import estaticos.Mundo;
import login.LoginServer;
import variables.Cuenta;
import variables.Servidor;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Maneja la comunicación con un servidor de juego conectado
 * Protocolo de sincronización:
 * 
 * RECIBIDOS (del servidor de juego):
 * D{id};{puerto};{prioridad};{estado};{ip} - Registro del servidor
 * S{estado} - Cambio de estado
 * C{conectados} - Cantidad de jugadores conectados
 * I{ip};{cantidad} - Cantidad de conexiones desde una IP
 * A{cuentaId};{cantPersonajes} - Actualización de personajes
 * 
 * ENVIADOS (al servidor de juego):
 * A{cuentaId};{ip} - Notificar conexión de cuenta
 * I{ip} - Solicitar cantidad de IPs
 */
public class SincronizadorSocket implements Runnable {
    
    private Socket socket;
    private BufferedInputStream in;
    private PrintWriter out;
    private Servidor servidor;
    private String ip;
    private boolean corriendo;
    
    public SincronizadorSocket(Socket socket) {
        try {
            this.socket = socket;
            this.ip = socket.getInetAddress().getHostAddress();
            this.in = new BufferedInputStream(socket.getInputStream());
            this.out = new PrintWriter(socket.getOutputStream());
            this.corriendo = true;
            
            Thread thread = new Thread(this);
            thread.setDaemon(true);
            thread.start();
            
        } catch (IOException e) {
            MainMultiLogin.escribirLog("[SYNC] Error al crear socket: " + e.getMessage());
            desconectar();
        }
    }
    
    @Override
    public void run() {
        try {
            // Pequeña pausa para estabilizar conexión
            Thread.sleep(500);
            
            int c;
            int length = -1;
            int index = 0;
            byte[] bytes = new byte[1];
            
            while (corriendo && (c = in.read()) != -1) {
                if (length == -1) {
                    length = in.available();
                    bytes = new byte[length + 1];
                    index = 0;
                }
                
                bytes[index++] = (byte) c;
                
                if (bytes.length == index) {
                    String tempPacket = new String(bytes, StandardCharsets.UTF_8);
                    for (String packet : tempPacket.split("[\u0000\n\r]")) {
                        if (!packet.isEmpty()) {
                            procesarPacket(packet);
                        }
                    }
                    length = -1;
                }
            }
        } catch (Exception e) {
            if (corriendo) {
                MainMultiLogin.escribirLog("[SYNC] Error en conexión: " + e.getMessage());
            }
        } finally {
            if (servidor != null) {
                System.out.println("[SYNC] <<< Servidor " + servidor.getId() + " desconectado >>>");
            }
            desconectar();
        }
    }
    
    /**
     * Procesa un packet recibido del servidor de juego
     */
    private void procesarPacket(String packet) {
        if (MainMultiLogin.MOSTRAR_SINCRONIZACION) {
            System.out.println("[SYNC] << Recibido: " + packet);
        }
        
        try {
            char tipo = packet.charAt(0);
            String datos = packet.substring(1);
            
            switch (tipo) {
                case 'D': // Registro del servidor
                    procesarRegistro(datos);
                    break;
                    
                case 'S': // Cambio de estado
                    procesarCambioEstado(datos);
                    break;
                    
                case 'C': // Cantidad de conectados
                    procesarConectados(datos);
                    break;
                    
                case 'I': // Cantidad por IP
                    procesarCantidadIP(datos);
                    break;
                    
                case 'A': // Actualización de personajes
                    procesarActualizacionPersonajes(datos);
                    break;
                    
                default:
                    // Packet desconocido - posiblemente del cliente 1.43.7 o servidor actualizado
                    String servidorInfo = servidor != null ? "Servidor " + servidor.getId() : "Servidor desconocido";
                    System.out.println("[MULTILOGIN-SYNC] >>> PACKET DESCONOCIDO <<<");
                    System.out.println("[MULTILOGIN-SYNC] IP: " + ip + " | " + servidorInfo);
                    System.out.println("[MULTILOGIN-SYNC] Packet: " + packet);
                    System.out.println("[MULTILOGIN-SYNC] Primer caracter: '" + tipo + "' (ASCII: " + (int)tipo + ")");
                    System.out.println("[MULTILOGIN-SYNC] Longitud: " + packet.length());
                    System.out.println("[MULTILOGIN-SYNC] ========================================");
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error procesando packet: " + e.getMessage());
        }
    }
    
    /**
     * Procesa el registro de un servidor de juego
     * Formato: id;puerto;prioridad;estado;ip
     */
    private void procesarRegistro(String datos) {
        try {
            String[] partes = datos.split(";");
            int id = Integer.parseInt(partes[0]);
            int puerto = Integer.parseInt(partes[1]);
            int prioridad = Integer.parseInt(partes[2]);
            int estado = Integer.parseInt(partes[3]);
            String ipServidor = partes.length > 4 ? partes[4] : ip;
            
            // Buscar o crear servidor
            servidor = Mundo.getServidor(id);
            if (servidor == null) {
                servidor = new Servidor(id, puerto, estado);
                Mundo.addServidor(servidor);
            } else {
                servidor.setPuerto(puerto);
            }
            
            servidor.setIp(ipServidor);
            servidor.setPrioridad(prioridad);
            servidor.setEstado(estado);
            servidor.setConector(this);
            
            System.out.println("[SYNC] >>> Servidor " + id + " conectado (IP: " + ipServidor + ", Puerto: " + puerto + ") <<<");
            
            // Notificar a los clientes que están esperando
            LoginServer.actualizarEstadoServidores();
            
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error en registro: " + e.getMessage());
        }
    }
    
    /**
     * Procesa cambio de estado del servidor
     */
    private void procesarCambioEstado(String datos) {
        try {
            int estado = Integer.parseInt(datos);
            if (servidor != null) {
                if (estado == Servidor.SERVIDOR_OFFLINE) {
                    desconectar();
                } else {
                    servidor.setEstado(estado);
                    LoginServer.actualizarEstadoServidores();
                }
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error en cambio estado: " + e.getMessage());
        }
    }
    
    /**
     * Procesa actualización de jugadores conectados
     */
    private void procesarConectados(String datos) {
        try {
            int conectados = Integer.parseInt(datos);
            if (servidor != null) {
                servidor.setConectados(conectados);
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error en conectados: " + e.getMessage());
        }
    }
    
    /**
     * Procesa cantidad de conexiones desde una IP
     */
    private void procesarCantidadIP(String datos) {
        try {
            String[] partes = datos.split(";");
            String ipCliente = partes[0];
            int cantidad = Integer.parseInt(partes[1]);
            if (servidor != null) {
                servidor.setCantidadIp(ipCliente, cantidad);
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error en cantidad IP: " + e.getMessage());
        }
    }
    
    /**
     * Procesa actualización de personajes de una cuenta
     */
    private void procesarActualizacionPersonajes(String datos) {
        try {
            String[] partes = datos.split(";");
            int cuentaId = Integer.parseInt(partes[0]);
            int cantPersonajes = Integer.parseInt(partes[1]);
            
            Cuenta cuenta = Mundo.getCuenta(cuentaId);
            if (cuenta != null && servidor != null) {
                cuenta.setPersonajes(servidor.getId(), cantPersonajes);
            }
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error en personajes: " + e.getMessage());
        }
    }
    
    /**
     * Envía un packet al servidor de juego
     */
    public void enviarPacket(String packet) {
        if (out == null || packet == null || packet.isEmpty()) return;
        
        if (MainMultiLogin.MOSTRAR_SINCRONIZACION) {
            System.out.println("[SYNC] >> Enviando: " + packet);
        }
        
        try {
            packet = Encriptador.aUTF(packet);
            out.print(packet + (char) 0x00);
            out.flush();
        } catch (Exception e) {
            MainMultiLogin.escribirLog("[SYNC] Error enviando: " + e.getMessage());
        }
    }
    
    /**
     * Verifica si el socket está cerrado
     */
    public boolean estaCerrado() {
        return socket == null || socket.isClosed();
    }
    
    /**
     * Desconecta el socket
     */
    private void desconectar() {
        corriendo = false;
        
        try {
            if (servidor != null) {
                servidor.setConector(null);
                servidor.setEstado(Servidor.SERVIDOR_OFFLINE);
                LoginServer.actualizarEstadoServidores();
            }
            
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null && !socket.isClosed()) socket.close();
            
        } catch (IOException e) {
            MainMultiLogin.escribirLog("[SYNC] Error al desconectar: " + e.getMessage());
        }
    }
}

